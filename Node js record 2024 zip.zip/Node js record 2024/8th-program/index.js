const express = require('express');
const mysql = require('mysql');

const app = express();
const port = 3005;

// Create a MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // default XAMPP MySQL user
    password: '', // default XAMPP MySQL password
    database: 'product_database' // Ensure this matches your database name
});

// Connect to the database
connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Database!');
});

// Middleware to parse JSON
app.use(express.json());

// Route to show all products
app.get('/product', (req, res) => {
    connection.query('SELECT * FROM Product', (err, results) => { // Ensure table name is correct
        if (err) throw err;
        res.json(results);
    });
});

// Route to update product prices
app.put('/product/update-prices', (req, res) => {
    connection.query('UPDATE Product SET unit_price = unit_price + 10', (err, results) => {
        if (err) throw err;
        res.send('All product prices updated by 10 Rupees.');
    });
});

// Route to delete a product by ID
app.delete('/product/:id', (req, res) => {
  //  const productId = req.params.id; // Corrected variable name
    connection.query('DELETE FROM product WHERE prd_id = 2',  (err, results) => { // Ensure table name is correct
        if (err) throw err;
        res.send(`deleted the id `);
        //res.send(`Product with ID ${productId} deleted.`);
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});