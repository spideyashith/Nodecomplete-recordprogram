const nodemailer = require('nodemailer');

// Create a transporter object using SMTP transport
const transporter = nodemailer.createTransport({
    host: 'smtp.gmail.com', // Replace with your SMTP server
    port: 465, // Usually 587 for TLS
    secure: true, // true for 465, false for other ports
    auth: {
        user: 'ashithfernandes319@gmail.com', // Your email address
        pass: 'ecvqexkkgfcokbag' // Your email password
    }
});

// Set up email data
const mailOptions = {
    from: 'ashithfernandes319@gmail.com', // Sender address
    to: 'fernandesashith24@gmail.com', // List of recipients
    subject: 'Hello from Node.js', // Subject line
    text: 'This is a test email sent from a Node.js application!', // Plain text body
    html: '<b>This is a test email sent from a Node.js application!</b>' // HTML body
};

// Send mail with defined transport object
transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
        return console.log('Error occurred: ' + error.message);
    }
    console.log('Message sent: %s', info.messageId);
});