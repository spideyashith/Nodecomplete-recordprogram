const fs = require('fs');
const path = require('path');

// Define file paths
const filePath = path.join(__dirname, 'example.txt');
const newFilePath = path.join(__dirname, 'renamed_example.txt');

// 1. Write to a file
function writeFile(callback) {
    const content = 'Hello, this is a sample text!';
    fs.writeFile(filePath, content, (err) => {
        if (err) {
            console.error('Error writing to file:', err);
            return;
        }
        console.log('File written successfully.');
        callback(); // Call the next function
    });
}

// 2. Read from a file
function readFile(callback) {
    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error('Error reading file:', err);
            return;
        }
        console.log('File content:', data);
        callback(); // Call the next function
    });
}

// 3. Append to a file
function appendToFile(callback) {
    const additionalContent = '\nThis is additional text appended to the file.';
    fs.appendFile(filePath, additionalContent, (err) => {
        if (err) {
            console.error('Error appending to file:', err);
            return;
        }
        console.log('Content appended successfully.');
        callback(); // Call the next function
    });
}

// 4. Rename the file
function renameFile(callback) {
    fs.rename(filePath, newFilePath, (err) => {
        if (err) {
            console.error('Error renaming file:', err);
            return;
        }
        console.log('File renamed successfully to', newFilePath);
        callback(); // Call the next function
    });
}

// 5. Delete the file
function deleteFile() {
    fs.unlink(newFilePath, (err) => {
        if (err) {
            console.error('Error deleting file:', err);
            return;
        }
        console.log('File deleted successfully.');
    });
}

// Start the file operations
writeFile(() => {
    readFile(() => {
        appendToFile(() => {
            renameFile(() => {
                deleteFile(); // Delete after renaming
            });
        });
    });
});