// Import necessary modules
const express = require('express');
const mysql = require('mysql');

const app = express();
const port = 3020;

// Middleware to parse JSON
app.use(express.json());

// Create MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Replace with your MySQL username
  password: '', // Replace with your MySQL password
  database: 'prd_db', // Replace with your database name
});

db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL database.');
});

// Create Products table
app.get('/create-table', (req, res) => {
  const sql = `CREATE TABLE IF NOT EXISTS Products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(255) NOT NULL,
    UnitPrice DECIMAL(10, 2) NOT NULL,
    StockAvailable INT NOT NULL,
    ExpiryDate DATE NOT NULL
  )`;

  db.query(sql, (err) => {
    if (err) throw err;
    res.send('Products table created.');
  });
});

// Add 5 products
app.post('/add-products', (req, res) => {
  const products = [
    ['Milk', 50.00, 20, '2025-01-30'],
    ['Bread', 30.00, 50, '2025-01-20'],
    ['Eggs', 60.00, 100, '2025-02-10'],
    ['Cheese', 200.00, 10, '2025-02-28'],
    ['Butter', 150.00, 15, '2025-03-05'],
  ];

  const sql = 'INSERT INTO Products (ProductName, UnitPrice, StockAvailable, ExpiryDate) VALUES ?';

  db.query(sql, [products], (err) => {
    if (err) throw err;
    res.send('5 products added.');
  });
});

// Show all products
app.get('/products', (req, res) => {
  const sql = 'SELECT * FROM Products';

  db.query(sql, (err, results) => {
    if (err) throw err;
    res.send(`
      <html>
        <head>
          <title>Product List</title>
          <style>
            table { width: 50%; margin: auto; border-collapse: collapse; }
            th, td { border: 1px solid black; padding: 10px; text-align: center; }
            th { background-color: #f2f2f2; }
          </style>
        </head>
        <body>
          <h1 style="text-align: center;">Products</h1>
          <table>
            <tr>
              <th>Product ID</th>
              <th>Product Name</th>
              <th>Unit Price</th>
              <th>Stock Available</th>
              <th>Expiry Date</th>
            </tr>
            ${results.map(product => `
              <tr>
                <td>${product.ProductID}</td>
                <td>${product.ProductName}</td>
                <td>${product.UnitPrice}</td>
                <td>${product.StockAvailable}</td>
                <td>${product.ExpiryDate}</td>
              </tr>
            `).join('')}
          </table>
        </body>
      </html>
    `);
  });
});

// Update Unit Price by 10 Rupees
app.put('/update-prices', (req, res) => {
  const sql = 'UPDATE Products SET UnitPrice = UnitPrice + 10';

  db.query(sql, (err) => {
    if (err) throw err;
    res.send('Unit prices updated by 10 rupees.');
  });
});

// Delete a product
app.delete('/delete-product/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM Products WHERE ProductID = ?';

  db.query(sql, [id], (err) => {
    if (err) throw err;
    res.send(`Product with ID ${id} deleted.`);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
