const mysql = require('mysql');
const util = require('util');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mydatabase'
});

connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database!');
});

// Promisify the query function
const query = util.promisify(connection.query).bind(connection);

(async () => {
    try {
        // b) Add 5 Products
        const products = [
            ['Product1', 100, 50, '2025-12-31'],
            ['Product2', 200, 30, '2025-11-30'],
            ['Product3', 150, 20, '2025-10-31'],
            ['Product4', 250, 10, '2025-09-30'],
            ['Product5', 300, 5, '2025-08-31']
        ];

        for (const product of products) {
            const queryStr = 'INSERT INTO Products (ProductName, UnitPrice, StockAvailable, ExpiryDate) VALUES (?, ?, ?, ?)';
            const result = await query(queryStr, product);
            console.log('Product added:', result.insertId);
        }

        // c) Show all the Products in a Neat format
        let results = await query('SELECT * FROM Products');
        console.log('All Products:');
        console.table(results);

        // d) Update all the Unit Price to be increased by 10 Rupees
        await query('UPDATE Products SET UnitPrice = UnitPrice + 10');
        console.log('Unit Prices updated');

        // Show updated products
        results = await query('SELECT * FROM Products');
        console.log('All Products after price update:');
        console.table(results);

        // e) Delete a particular product and display all products again
        const productIdToDelete = 3; // Change this to the ProductID you want to delete
        await query('DELETE FROM Products WHERE ProductID = ?', [productIdToDelete]);
        console.log('Product deleted');

        results = await query('SELECT * FROM Products');
        console.log('All Products after deletion:');
        console.table(results);

    } catch (err) {
        console.error(err);
    } finally {
        connection.end();
    }
})();
