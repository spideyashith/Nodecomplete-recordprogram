const express = require('express');
const mysql = require('mysql');

const app = express();
const port = 3004;

// Create a MySQL connection
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root', // default XAMPP MySQL user
    password: '', // default XAMPP MySQL password
    database: 'product_db1'
});

// Connect to the database
connection.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL database.');
});

// Middleware to parse JSON
app.use(express.json());

// Route to show all products
app.get('/products', (req, res) => {
    connection.query('SELECT * FROM Products', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// Route to update product prices
app.put('/products/update-prices', (req, res) => {
    connection.query('UPDATE Products SET UnitPrice = UnitPrice + 10', (err, results) => {
        if (err) throw err;
        res.send('All product prices updated by 10 Rupees.');
    });
});

// Route to delete a product by ID
app.delete('/products/:id', (req, res) => {
    const productId = req.params.id;
    connection.query('DELETE FROM Products WHERE ProductID = ?', [productId], (err, results) => {
        if (err) throw err;
        res.send(`Product with ID ${productId} deleted.`);
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});