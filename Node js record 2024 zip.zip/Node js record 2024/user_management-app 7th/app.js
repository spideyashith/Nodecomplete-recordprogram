const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();
const port = 3002;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// MySQL Connection
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root', // default XAMPP MySQL user
    password: '', // default XAMPP MySQL password
    database: 'user_management1'
});

// Connect to MySQL
db.connect(err => {
    if (err) throw err;
    console.log('MySQL Connected...');
});

// Create Users Table (if not exists)
db.query(`CREATE TABLE IF NOT EXISTS Users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    UserName VARCHAR(50) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    EmailAddress VARCHAR(100) NOT NULL,
    DateOfBirth DATE NOT NULL
);`, (err, result) => {
    if (err) throw err;
});

// Add 5 Users
const users = [
    { UserName: 'JohnDoe', Password: 'password123', EmailAddress: 'john@example.com', DateOfBirth: '1990-01-01' },
    { UserName: 'JaneDoe', Password: 'password123', EmailAddress: 'jane@example.com', DateOfBirth: '1992-02-02' },
    { UserName: 'Alice', Password: 'password123', EmailAddress: 'alice@example.com', DateOfBirth: '1995-03-03' },
    { UserName: 'Bob', Password: 'password123', EmailAddress: 'bob@example.com', DateOfBirth: '1988-04-04' },
    { UserName: 'Charlie', Password: 'password123', EmailAddress: 'charlie@example.com', DateOfBirth: '1993-05-05' }
];

users.forEach(user => {
    db.query('INSERT INTO Users SET ?', user, (err, result) => {
        if (err) throw err;
    });
});

// Show all Users
app.get('/users', (req, res) => {
    db.query('SELECT * FROM Users', (err, results) => {
        if (err) throw err;
        res.json(results);
    });
});

// Update User
app.put('/users/:id', (req, res) => {
    const { id } = req.params;
    const { UserName, Password, EmailAddress, DateOfBirth } = req.body;
    db.query('UPDATE Users SET ? WHERE UserID = ?', [{ UserName, Password, EmailAddress, DateOfBirth }, id], (err, result) => {
        if (err) throw err;
        res.send('User  updated successfully');
    });
});

// Delete User
app.delete('/users/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM Users WHERE UserID = ?', [id], (err, result) => {
        if (err) throw err;
        res.send('User  deleted successfully');
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});